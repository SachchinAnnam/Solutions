import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IStandexCommunityGalleryWebPartProps {
    description: string;
    libName: string;
}
export default class StandexCommunityGalleryWebPart extends BaseClientSideWebPart<IStandexCommunityGalleryWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=StandexCommunityGalleryWebPart.d.ts.map