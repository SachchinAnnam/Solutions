declare const styles: {
    standexCommunityGallery: string;
    container: string;
    row: string;
    column: string;
    'ms-Grid': string;
    title: string;
    subTitle: string;
    description: string;
    gallery: string;
    desc: string;
    photosno: string;
    responsive: string;
    clearfix: string;
    button: string;
    label: string;
};
export default styles;
//# sourceMappingURL=StandexCommunityGallery.module.scss.d.ts.map