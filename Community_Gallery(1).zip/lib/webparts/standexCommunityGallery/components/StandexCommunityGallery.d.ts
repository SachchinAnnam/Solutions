import * as React from 'react';
import { IStandexCommunityGalleryProps } from './IStandexCommunityGalleryProps';
import { IStandexCommunityGallerystate } from './IStandexCommunityGallerystate';
export default class StandexCommunityGallery extends React.Component<IStandexCommunityGalleryProps, IStandexCommunityGallerystate> {
    constructor(props: IStandexCommunityGalleryProps, state: IStandexCommunityGallerystate);
    componentDidMount(): void;
    private getItems;
    private getItemCounts;
    render(): React.ReactElement<IStandexCommunityGalleryProps>;
}
//# sourceMappingURL=StandexCommunityGallery.d.ts.map