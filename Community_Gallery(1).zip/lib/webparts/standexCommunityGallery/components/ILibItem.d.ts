export interface ILibItem {
    Title?: string;
    Id: number;
}
//# sourceMappingURL=ILibItem.d.ts.map