import { ILibItem } from './ILibItem';
export interface IStandexCommunityGallerystate {
    status: string;
    items: ILibItem[];
    Title: string;
}
//# sourceMappingURL=IStandexCommunityGallerystate.d.ts.map