(window["webpackJsonp_8217e442_8ed3_41fd_957d_b112e841286a_0_8_16"] = window["webpackJsonp_8217e442_8ed3_41fd_957d_b112e841286a_0_8_16"] || []).push([["sp-client-telemetry-aria"],{

/***/ "GdB4":
/*!****************************!*\
  !*** ./lib/ariaWrapper.js ***!
  \****************************/
/*! exports provided: ariaWrapper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ariaWrapper", function() { return ariaWrapper; });
var ariaWrapper = __webpack_require__(/*! exports-loader?microsoft.applications.telemetry!@ms/aria-private */ "GMzq");


/***/ })

}]);
//# sourceMappingURL=chunk.sp-client-telemetry-aria_d48f1b4a7f35e0a67d7e.js.map