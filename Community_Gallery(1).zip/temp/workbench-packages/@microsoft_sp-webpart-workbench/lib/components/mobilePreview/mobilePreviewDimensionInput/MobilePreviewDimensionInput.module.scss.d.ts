declare const styles: {
    xField: string;
    yField: string;
    mobilePreviewTextfieldXY: string;
    xyTextfields: string;
    xyLabels: string;
};
export default styles;
//# sourceMappingURL=MobilePreviewDimensionInput.module.scss.d.ts.map