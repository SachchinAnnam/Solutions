import getPublic from './getPublic';
declare const _default: {
    '/workbench': (request: any, response: any) => void;
    '*/*': typeof getPublic;
};
export default _default;
//# sourceMappingURL=index.d.ts.map