export {};
//# sourceMappingURL=workbenchInit.d.ts.map