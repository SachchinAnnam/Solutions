export interface ILibItem {
  Title?: string;
  Id: number;
}
